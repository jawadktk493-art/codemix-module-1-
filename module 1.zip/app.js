// --- Storage helpers (localStorage stands in for a backend) ---
const Store = {
  getUsers() {
    return JSON.parse(localStorage.getItem('blog_users') || '[]');
  },
  saveUsers(users) {
    localStorage.setItem('blog_users', JSON.stringify(users));
  },
  getPosts() {
    return JSON.parse(localStorage.getItem('blog_posts') || '[]');
  },
  savePosts(posts) {
    localStorage.setItem('blog_posts', JSON.stringify(posts));
  },
  getCurrentUser() {
    const email = localStorage.getItem('blog_current_user');
    if (!email) return null;
    return this.getUsers().find(u => u.email === email) || null;
  },
  setCurrentUser(email) {
    localStorage.setItem('blog_current_user', email);
  },
  logout() {
    localStorage.removeItem('blog_current_user');
  }
};

// --- Nav rendering (same nav markup on every page) ---
function renderNav(activePage) {
  const user = Store.getCurrentUser();
  const nav = document.getElementById('nav-links');
  if (!nav) return;

  let links = '<a href="index.html">Home</a>';

  if (user) {
    links += `<a href="dashboard.html">Dashboard</a>
              <a href="create-blog.html">New Post</a>
              <button class="linklike" id="logout-btn">Log out</button>`;
  } else {
    links += `<a href="login.html">Log in</a>
              <a href="register.html">Register</a>`;
  }

  nav.innerHTML = links;

  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      Store.logout();
      window.location.href = 'index.html';
    });
  }
}

// Redirect guard for pages that require login
function requireLogin() {
  if (!Store.getCurrentUser()) {
    window.location.href = 'login.html';
  }
}

function formatDate(iso) {
  return new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}
